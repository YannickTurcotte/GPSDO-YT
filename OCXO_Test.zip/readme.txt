OCXO_Test.hex

Doing 5 reading at 10 seconds gate. 0% 25% 50% 75% and 100% of the 16 bits pwm range.

Those result help to know the range of your OCXO and to see the linearity.

Change pwm and wait 10 seconds before to start the count.
I checked with DMM and 10 Second is large enough to stabilise the voltage.